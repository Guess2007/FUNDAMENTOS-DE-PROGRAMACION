﻿using System;
using System.Collections.Generic;

namespace SistemaMatricula
{
    class Program
    {
        struct Estudiante
        {
            public string codigo;
            public string nombre;
            public string carrera;
            public int ciclo;
            public double promedio;
        }

        struct Curso
        {
            public string nombre;
            public int creditos;
        }

        static void Main(string[] args)
        {
            Estudiante estudiante = RegistrarEstudiante();
            List<Curso> cursos = RegistrarCursos();


            int totalCreditos = CalcularCreditos(cursos);
            string tipoMatricula = DeterminarTipoMatricula(totalCreditos);

           
            if (tipoMatricula == "Error")
            {
                Console.WriteLine("\n[ERROR] No puede matricularse con más de 22 créditos. Proceso cancelado."); 
                return;
            }

            double porcentajeDescuento = CalcularDescuento(estudiante.promedio);

            
            double subtotal, descuento, total;
            CalcularPago(totalCreditos, porcentajeDescuento, out subtotal, out descuento, out total);

            
            MostrarReporte(estudiante, cursos, totalCreditos, tipoMatricula, subtotal, descuento, total);
        }

        static Estudiante RegistrarEstudiante()
        {
            Estudiante est = new Estudiante();
            Console.WriteLine("--- REGISTRO DEL ESTUDIANTE ---");
            Console.Write("Código de estudiante: ");
            est.codigo = Console.ReadLine();
            Console.Write("Nombre completo: ");
            est.nombre = Console.ReadLine();
            Console.Write("Carrera profesional: ");
            est.carrera = Console.ReadLine();

            
            while (true)
            {
                Console.Write("Ciclo académico (1-10): ");
                if (int.TryParse(Console.ReadLine(), out est.ciclo) && est.ciclo >= 1 && est.ciclo <= 10)
                {
                    break;
                }
                Console.WriteLine("Error: El ciclo debe estar entre 1 y 10.");
            }

            
            while (true)
            {
                Console.Write("Promedio ponderado del semestre anterior (0-20): ");
                if (double.TryParse(Console.ReadLine(), out est.promedio) && est.promedio >= 0 && est.promedio <= 20)
                {
                    break;
                }
                Console.WriteLine("Error: El promedio debe estar entre 0 y 20.");
            }

            return est;
        }

        static List<Curso> RegistrarCursos()
        {
            Console.WriteLine("\n--- REGISTRO DE CURSOS ---");
            int nCursos;

            
            while (true)
            {
                Console.Write("¿Cuántos cursos va a matricular? (1-7): ");
                if (int.TryParse(Console.ReadLine(), out nCursos) && nCursos >= 1 && nCursos <= 7)
                {
                    break;
                }
                Console.WriteLine("Error: Solo puede registrar entre 1 y 7 cursos.");
            }

            List<Curso> listaCursos = new List<Curso>();

            for (int i = 0; i < nCursos; i++)
            {
                Curso nuevoCurso = new Curso();
                Console.WriteLine($"\nCurso {i + 1}:");
                Console.Write("  Nombre del curso: ");
                nuevoCurso.nombre = Console.ReadLine();

                
                while (true)
                {
                    Console.Write("  Cantidad de créditos: ");
                    if (int.TryParse(Console.ReadLine(), out nuevoCurso.creditos) && nuevoCurso.creditos >= 0)
                    {
                        break;
                    }
                    Console.WriteLine("  Error: No se permiten créditos negativos.");
                }

                listaCursos.Add(nuevoCurso);
            }

            return listaCursos;
        }

        static int CalcularCreditos(List<Curso> cursos)
        {
            int total = 0;
            foreach (var curso in cursos)
            {
                total += curso.creditos; 
            }
            return total;
        }

        static string DeterminarTipoMatricula(int creditos)
        {
            if (creditos < 12)
            {
                return "Matrícula de tiempo parcial"; 
            }
            else if (creditos >= 12 && creditos <= 22)
            {
                return "Matrícula regular"; 
            }
            else
            {
                return "Error"; 
            }
        }

        static double CalcularDescuento(double promedio)
        {
            
            if (promedio >= 18 && promedio <= 20)
            {
                return 0.20; // 20%
            }
            else if (promedio >= 16 && promedio < 18)
            {
                return 0.10; // 10%
            }
            else
            {
                return 0.00; // 0%
            }
        }

        static void CalcularPago(int creditos, double porcentajeDescuento, out double subtotal, out double descuento, out double total)
        {
            double costoPorCredito = 85.00; 
            subtotal = creditos * costoPorCredito;
            descuento = subtotal * porcentajeDescuento;
            total = subtotal - descuento;
        }

        static void MostrarReporte(Estudiante est, List<Curso> cursos, int totalCreditos, string tipo, double subtotal, double descuento, double total)
        {
            Console.WriteLine("\n===============================================");
            Console.WriteLine("           REPORTE FINAL DE MATRÍCULA          "); 
            Console.WriteLine("===============================================");
            Console.WriteLine($"Código: {est.codigo}");
            Console.WriteLine($"Estudiante: {est.nombre}");
            Console.WriteLine($"Carrera: {est.carrera}");
            Console.WriteLine($"Ciclo: {est.ciclo} | Promedio: {est.promedio}");
            Console.WriteLine("-----------------------------------------------");
            Console.WriteLine("Cursos Registrados:");
            foreach (var c in cursos)
            {
                Console.WriteLine($" - {c.nombre} ({c.creditos} créditos)");
            }
            Console.WriteLine("-----------------------------------------------");
            Console.WriteLine($"Total de Créditos: {totalCreditos}");
            Console.WriteLine($"Tipo de Matrícula: {tipo}");
            Console.WriteLine($"Subtotal: S/ {subtotal:F2}");
            Console.WriteLine($"Descuento Aplicado: S/ {descuento:F2}");
            Console.WriteLine($"Total a Pagar: S/ {total:F2}");
            Console.WriteLine("===============================================");
        }
    }
}