﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace proyFrmprincipal
{
    internal class Lista
    {
        public nodo ini, fin, aux;
        public Lista()
        {
            ini = null;
            fin = null;
            aux = null;
        }
        public void Insertar(int numero)
        {
            nodo nuevo = new nodo();
            nuevo.numero = numero;
            if (ini == null)
            {
                ini =fin = nuevo;
                nuevo.sig = null;
                nuevo.ant = null;

                //fin = nuevo;
            }
            else
            {
                fin.sig = nuevo;
                nuevo.ant = fin;
                fin = nuevo;
                nuevo.sig = null;
                                                
            }
        }
        // MessageBox.Show("Estoy Insertando!!");

        public string ListaAlaDerecha() 
        {
        string acumcad = "";
            aux =ini;
            while (aux != null)
            {
                acumcad = acumcad + aux.numero + ",";
                aux =aux.sig;
            }
        return acumcad;
        }

        public string ListaAlaIzquierda()
        {
            string acumcad = "";
            aux = ini;
            while (aux != null)
            {
                acumcad = acumcad + aux.numero + ",";
                aux = aux.sig;
            }
            return acumcad;
        }
        public string Imprimir()
        {
            nodo p;
            p = ini;
            string acumcad = "";
            while (p != null)
            {
                acumcad = acumcad + p.numero.ToString() + " , ";
                p = p.sig;

            }
            return acumcad;
        }
        //MessageBox.Show("estoy Imprimiendo!!!");

        public void Ordenar()
        {
            nodo p, q;
            p = ini;
            int aux;

            while (p.sig != null)
            {
                q = p.sig;
                while (q != null)
                {
                    if (p.numero > q.numero)
                    {
                        aux = p.numero;
                        p.numero = q.numero;
                        q.numero = aux;
                    }
                    q = q.sig;

                }

                p = p.sig;
            }
        }
    } 
    // MessageBox.Show("Estoy Ordenando!!");
        
        
    }

