﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace proyFrmprincipal
{
    internal class nodo
    {
        public int numero;
        public nodo sig ,ant;

    }
}
