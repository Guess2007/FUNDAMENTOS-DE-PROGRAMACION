﻿namespace proyFrmprincipal
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.txtNunero = new System.Windows.Forms.TextBox();
            this.btnAgregar = new System.Windows.Forms.Button();
            this.btnListar = new System.Windows.Forms.Button();
            this.btnOrdenar = new System.Windows.Forms.Button();
            this.txtRes = new System.Windows.Forms.TextBox();
            this.btnListarDerecha = new System.Windows.Forms.Button();
            this.btnListarIzquierda = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(180, 84);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(65, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Ingrese Nro:";
            // 
            // txtNunero
            // 
            this.txtNunero.Location = new System.Drawing.Point(335, 84);
            this.txtNunero.Name = "txtNunero";
            this.txtNunero.Size = new System.Drawing.Size(343, 20);
            this.txtNunero.TabIndex = 1;
            // 
            // btnAgregar
            // 
            this.btnAgregar.Location = new System.Drawing.Point(204, 146);
            this.btnAgregar.Name = "btnAgregar";
            this.btnAgregar.Size = new System.Drawing.Size(75, 23);
            this.btnAgregar.TabIndex = 2;
            this.btnAgregar.Text = "Agregar";
            this.btnAgregar.UseVisualStyleBackColor = true;
            this.btnAgregar.Click += new System.EventHandler(this.btnAgregar_Click);
            // 
            // btnListar
            // 
            this.btnListar.Location = new System.Drawing.Point(378, 146);
            this.btnListar.Name = "btnListar";
            this.btnListar.Size = new System.Drawing.Size(75, 23);
            this.btnListar.TabIndex = 2;
            this.btnListar.Text = "Listar";
            this.btnListar.UseVisualStyleBackColor = true;
            this.btnListar.Click += new System.EventHandler(this.btnListar_Click);
            // 
            // btnOrdenar
            // 
            this.btnOrdenar.Location = new System.Drawing.Point(297, 146);
            this.btnOrdenar.Name = "btnOrdenar";
            this.btnOrdenar.Size = new System.Drawing.Size(75, 23);
            this.btnOrdenar.TabIndex = 2;
            this.btnOrdenar.Text = "Ordenar";
            this.btnOrdenar.UseVisualStyleBackColor = true;
            this.btnOrdenar.Click += new System.EventHandler(this.btnOrdenar_Click);
            // 
            // txtRes
            // 
            this.txtRes.Location = new System.Drawing.Point(183, 205);
            this.txtRes.Multiline = true;
            this.txtRes.Name = "txtRes";
            this.txtRes.Size = new System.Drawing.Size(495, 199);
            this.txtRes.TabIndex = 3;
            // 
            // btnListarDerecha
            // 
            this.btnListarDerecha.Location = new System.Drawing.Point(475, 146);
            this.btnListarDerecha.Name = "btnListarDerecha";
            this.btnListarDerecha.Size = new System.Drawing.Size(90, 23);
            this.btnListarDerecha.TabIndex = 2;
            this.btnListarDerecha.Text = "Listar_Derecha";
            this.btnListarDerecha.UseVisualStyleBackColor = true;
            this.btnListarDerecha.Click += new System.EventHandler(this.btnListar_Click);
            // 
            // btnListarIzquierda
            // 
            this.btnListarIzquierda.Location = new System.Drawing.Point(586, 146);
            this.btnListarIzquierda.Name = "btnListarIzquierda";
            this.btnListarIzquierda.Size = new System.Drawing.Size(102, 23);
            this.btnListarIzquierda.TabIndex = 2;
            this.btnListarIzquierda.Text = "Listar_Izquierda";
            this.btnListarIzquierda.UseVisualStyleBackColor = true;
            this.btnListarIzquierda.Click += new System.EventHandler(this.btnListar_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(990, 495);
            this.Controls.Add(this.txtRes);
            this.Controls.Add(this.btnListarIzquierda);
            this.Controls.Add(this.btnListarDerecha);
            this.Controls.Add(this.btnListar);
            this.Controls.Add(this.btnOrdenar);
            this.Controls.Add(this.btnAgregar);
            this.Controls.Add(this.txtNunero);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtNunero;
        private System.Windows.Forms.Button btnAgregar;
        private System.Windows.Forms.Button btnListar;
        private System.Windows.Forms.Button btnOrdenar;
        private System.Windows.Forms.TextBox txtRes;
        private System.Windows.Forms.Button btnListarDerecha;
        private System.Windows.Forms.Button btnListarIzquierda;
    }
}

