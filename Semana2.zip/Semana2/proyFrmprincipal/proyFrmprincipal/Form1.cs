﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace proyFrmprincipal
{
    public partial class Form1 : Form
    {
        private readonly int x;
        private Lista objLista = new Lista();
        public Form1()
        {
            InitializeComponent();
            txtNunero.Text = ""; //limpiar
            txtNunero.Focus();
        }
        
        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnAgregar_Click(object sender, EventArgs e)
       
        {if (txtNunero.Text.Length > 0) 
            {
                int numero = int.Parse(txtNunero.Text);
                objLista.Insertar(numero);
                InitializeComponent();
                txtNunero.Text = ""; //limpiar
                txtNunero.Focus();
            }else
            {
                MessageBox.Show("por favor ingrese datos");
                txtNunero = null;


            }
        }

        private void btnOrdenar_Click(object sender, EventArgs e)
        {
            objLista.Ordenar();
        }

        private void btnListar_Click(object sender, EventArgs e)
        {
            string acumcad = objLista.Imprimir();
            txtRes.Text = acumcad;  
        }
    }
}
