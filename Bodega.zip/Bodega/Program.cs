using System;

namespace Bodega
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = System.Text.Encoding.UTF8;
            var app = new BodegaApp();
            app.Ejecutar();
        }
    }
}
