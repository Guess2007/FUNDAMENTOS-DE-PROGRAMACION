namespace Bodega
{
    public class Producto
    {
        public int Id { get; set; }
        public string Nombre { get; set; }
        public string Categoria { get; set; }
        public int Stock { get; set; }
        public decimal PrecioUnitario { get; set; }
        public string Proveedor { get; set; }
        public DateTime FechaIngreso { get; set; }

        // Formato CSV: Id|Nombre|Categoria|Stock|PrecioUnitario|Proveedor|FechaIngreso
        public string ToCsv()
        {
            return $"{Id}|{Nombre}|{Categoria}|{Stock}|{PrecioUnitario}|{Proveedor}|{FechaIngreso:yyyy-MM-dd}";
        }

        public static Producto FromCsv(string linea)
        {
            var partes = linea.Split('|');
            return new Producto
            {
                Id            = int.Parse(partes[0]),
                Nombre        = partes[1],
                Categoria     = partes[2],
                Stock         = int.Parse(partes[3]),
                PrecioUnitario = decimal.Parse(partes[4]),
                Proveedor     = partes[5],
                FechaIngreso  = DateTime.Parse(partes[6])
            };
        }

        public override string ToString()
        {
            return $"[{Id:D4}] {Nombre,-25} | {Categoria,-15} | Stock: {Stock,6} | S/ {PrecioUnitario,8:F2} | {Proveedor}";
        }
    }
}
