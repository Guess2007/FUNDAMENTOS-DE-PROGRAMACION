# Sistema de Gestión de Bodega en C#

## Estructura del proyecto

```
Bodega/
├── Program.cs        → Punto de entrada
├── BodegaApp.cs      → Menús e interfaz de consola
├── BodegaDB.cs       → Capa de datos (System.IO)
├── Producto.cs       → Modelo de producto
├── Movimiento.cs     → Modelo de movimiento de inventario
├── Bodega.csproj     → Archivo de proyecto (.NET 8)
└── datos/            → Carpeta creada automáticamente
    ├── productos.txt     → Base de datos de productos (CSV con |)
    ├── movimientos.txt   → Historial de movimientos
    └── contadores.txt    → IDs autoincrementales
```

## Requisitos

- .NET 8 SDK o superior
- Descárgalo en: https://dotnet.microsoft.com/download

## Cómo ejecutar

```bash
# Desde la carpeta Bodega/
dotnet run
```

## Cómo compilar (ejecutable independiente)

```bash
# Windows
dotnet publish -c Release -r win-x64 --self-contained true

# Linux/Mac
dotnet publish -c Release -r linux-x64 --self-contained true
```

## Funcionalidades

### Gestión de Productos
- Listar todos los productos
- Buscar por ID, nombre o categoría
- Agregar, editar y eliminar productos
- Alerta visual de stock bajo (≤5 unidades)

### Movimientos de Inventario
- Registrar **entradas** (compras/devoluciones)
- Registrar **salidas** (ventas/despachos)
- **Ajuste** manual de inventario
- Historial completo con fecha y motivo

### Reportes
- Resumen general (totales y valor del inventario)
- Productos con stock bajo (umbral configurable)
- Inventario valorizado agrupado por categoría

## Formato de los archivos TXT

### productos.txt
```
Id|Nombre|Categoria|Stock|PrecioUnitario|Proveedor|FechaIngreso
1|Arroz 50kg|Granos|25|85.00|AgroSur SAC|2025-01-10
```

### movimientos.txt
```
Id|ProductoId|ProductoNombre|Tipo|Cantidad|Motivo|Fecha
1|1|Arroz 50kg|Entrada|10|Compra OC-001|2025-01-15 09:30:00
```
