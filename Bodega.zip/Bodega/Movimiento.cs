namespace Bodega
{
    public enum TipoMovimiento { Entrada, Salida, Ajuste }

    public class Movimiento
    {
        public int Id { get; set; }
        public int ProductoId { get; set; }
        public string ProductoNombre { get; set; }
        public TipoMovimiento Tipo { get; set; }
        public int Cantidad { get; set; }
        public string Motivo { get; set; }
        public DateTime Fecha { get; set; }

        public string ToCsv()
        {
            return $"{Id}|{ProductoId}|{ProductoNombre}|{Tipo}|{Cantidad}|{Motivo}|{Fecha:yyyy-MM-dd HH:mm:ss}";
        }

        public static Movimiento FromCsv(string linea)
        {
            var partes = linea.Split('|');
            return new Movimiento
            {
                Id             = int.Parse(partes[0]),
                ProductoId     = int.Parse(partes[1]),
                ProductoNombre = partes[2],
                Tipo           = Enum.Parse<TipoMovimiento>(partes[3]),
                Cantidad       = int.Parse(partes[4]),
                Motivo         = partes[5],
                Fecha          = DateTime.Parse(partes[6])
            };
        }

        public override string ToString()
        {
            string icono = Tipo switch
            {
                TipoMovimiento.Entrada => "[+]",
                TipoMovimiento.Salida  => "[-]",
                _                      => "[=]"
            };
            return $"{icono} {Fecha:dd/MM/yyyy HH:mm} | {ProductoNombre,-25} | {Tipo,-7} | Cant: {Cantidad,5} | {Motivo}";
        }
    }
}
