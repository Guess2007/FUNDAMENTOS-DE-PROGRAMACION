namespace Bodega
{
    public class BodegaApp
    {
        private readonly BodegaDB _db;

        public BodegaApp()
        {
            _db = new BodegaDB();
        }

        // ── Punto de entrada ──────────────────────────────────────────────

        public void Ejecutar()
        {
            MostrarBienvenida();

            bool salir = false;
            while (!salir)
            {
                MostrarMenuPrincipal();
                string opcion = Leer("Seleccione una opción");

                switch (opcion)
                {
                    case "1": MenuProductos();   break;
                    case "2": MenuInventario();  break;
                    case "3": MenuReportes();    break;
                    case "4": salir = true;      break;
                    default:  Error("Opción no válida."); break;
                }
            }

            Console.WriteLine("\n  ¡Hasta luego! Sistema cerrado.\n");
        }

        // ── Menús ─────────────────────────────────────────────────────────

        private void MostrarMenuPrincipal()
        {
            Console.WriteLine();
            Separador("MENÚ PRINCIPAL");
            Console.WriteLine("  1. Gestión de Productos");
            Console.WriteLine("  2. Movimientos de Inventario");
            Console.WriteLine("  3. Reportes");
            Console.WriteLine("  4. Salir");
            Console.WriteLine();
        }

        // ── PRODUCTOS ─────────────────────────────────────────────────────

        private void MenuProductos()
        {
            bool volver = false;
            while (!volver)
            {
                Console.WriteLine();
                Separador("GESTIÓN DE PRODUCTOS");
                Console.WriteLine("  1. Listar todos los productos");
                Console.WriteLine("  2. Buscar producto");
                Console.WriteLine("  3. Agregar producto");
                Console.WriteLine("  4. Editar producto");
                Console.WriteLine("  5. Eliminar producto");
                Console.WriteLine("  6. Volver");
                Console.WriteLine();

                switch (Leer("Opción"))
                {
                    case "1": ListarProductos();  break;
                    case "2": BuscarProducto();   break;
                    case "3": AgregarProducto();  break;
                    case "4": EditarProducto();   break;
                    case "5": EliminarProducto(); break;
                    case "6": volver = true;      break;
                    default:  Error("Opción no válida."); break;
                }
            }
        }

        private void ListarProductos()
        {
            var productos = _db.ObtenerProductos();
            Console.WriteLine();
            Separador("LISTA DE PRODUCTOS");

            if (!productos.Any())
            {
                Console.WriteLine("  No hay productos registrados.");
                return;
            }

            Console.WriteLine($"  {"ID",-6} {"Nombre",-25} {"Categoría",-15} {"Stock",8} {"Precio",10} {"Proveedor",-20}");
            Console.WriteLine("  " + new string('─', 90));

            foreach (var p in productos.OrderBy(p => p.Nombre))
            {
                string alerta = p.Stock <= 5 ? " ⚠" : "";
                Console.WriteLine($"  [{p.Id:D4}] {p.Nombre,-25} {p.Categoria,-15} {p.Stock,8} S/{p.PrecioUnitario,9:F2} {p.Proveedor,-20}{alerta}");
            }

            Console.WriteLine($"\n  Total: {productos.Count} productos");
            Pausa();
        }

        private void BuscarProducto()
        {
            Console.WriteLine();
            Separador("BUSCAR PRODUCTO");
            Console.WriteLine("  1. Por ID");
            Console.WriteLine("  2. Por nombre");
            Console.WriteLine("  3. Por categoría");

            switch (Leer("Opción"))
            {
                case "1":
                    int id = LeerEntero("ID del producto");
                    var p = _db.BuscarProducto(id);
                    if (p != null) MostrarDetalleProducto(p);
                    else Error("Producto no encontrado.");
                    break;

                case "2":
                    string nombre = Leer("Nombre (parcial)");
                    var porNombre = _db.BuscarProductosPorNombre(nombre);
                    MostrarListaSimple(porNombre);
                    break;

                case "3":
                    var cats = _db.ObtenerCategorias();
                    if (!cats.Any()) { Error("No hay categorías registradas."); break; }
                    Console.WriteLine("\n  Categorías disponibles:");
                    for (int i = 0; i < cats.Count; i++)
                        Console.WriteLine($"  {i + 1}. {cats[i]}");
                    string cat = Leer("Nombre de categoría");
                    var porCat = _db.BuscarProductosPorCategoria(cat);
                    MostrarListaSimple(porCat);
                    break;
            }
        }

        private void MostrarDetalleProducto(Producto p)
        {
            Console.WriteLine();
            Separador("DETALLE DEL PRODUCTO");
            Console.WriteLine($"  ID           : {p.Id:D4}");
            Console.WriteLine($"  Nombre       : {p.Nombre}");
            Console.WriteLine($"  Categoría    : {p.Categoria}");
            Console.WriteLine($"  Stock actual : {p.Stock} unidades{(p.Stock <= 5 ? " ⚠ STOCK BAJO" : "")}");
            Console.WriteLine($"  Precio unit. : S/ {p.PrecioUnitario:F2}");
            Console.WriteLine($"  Valor total  : S/ {p.Stock * p.PrecioUnitario:F2}");
            Console.WriteLine($"  Proveedor    : {p.Proveedor}");
            Console.WriteLine($"  Fecha ingreso: {p.FechaIngreso:dd/MM/yyyy}");
            Pausa();
        }

        private void MostrarListaSimple(List<Producto> lista)
        {
            if (!lista.Any()) { Console.WriteLine("  No se encontraron productos."); Pausa(); return; }
            foreach (var p in lista)
                Console.WriteLine($"  {p}");
            Pausa();
        }

        private void AgregarProducto()
        {
            Console.WriteLine();
            Separador("AGREGAR PRODUCTO");

            var p = new Producto
            {
                Nombre        = Leer("Nombre"),
                Categoria     = Leer("Categoría"),
                Stock         = LeerEntero("Stock inicial"),
                PrecioUnitario = LeerDecimal("Precio unitario (S/)"),
                Proveedor     = Leer("Proveedor"),
                FechaIngreso  = DateTime.Today
            };

            var creado = _db.AgregarProducto(p);
            Exito($"Producto '{creado.Nombre}' agregado con ID {creado.Id:D4}.");
        }

        private void EditarProducto()
        {
            Console.WriteLine();
            Separador("EDITAR PRODUCTO");

            int id = LeerEntero("ID del producto a editar");
            var p = _db.BuscarProducto(id);

            if (p == null) { Error("Producto no encontrado."); return; }

            Console.WriteLine($"\n  Editando: {p.Nombre} (deje en blanco para mantener el valor actual)");

            string nombre = Leer($"Nombre [{p.Nombre}]");
            if (!string.IsNullOrWhiteSpace(nombre)) p.Nombre = nombre;

            string cat = Leer($"Categoría [{p.Categoria}]");
            if (!string.IsNullOrWhiteSpace(cat)) p.Categoria = cat;

            string precioStr = Leer($"Precio unitario [{p.PrecioUnitario:F2}]");
            if (decimal.TryParse(precioStr, out decimal precio)) p.PrecioUnitario = precio;

            string prov = Leer($"Proveedor [{p.Proveedor}]");
            if (!string.IsNullOrWhiteSpace(prov)) p.Proveedor = prov;

            _db.ActualizarProducto(p);
            Exito("Producto actualizado correctamente.");
        }

        private void EliminarProducto()
        {
            Console.WriteLine();
            Separador("ELIMINAR PRODUCTO");

            int id = LeerEntero("ID del producto a eliminar");
            var p = _db.BuscarProducto(id);

            if (p == null) { Error("Producto no encontrado."); return; }

            Console.WriteLine($"\n  ¿Eliminar '{p.Nombre}'? (s/n)");
            if (Console.ReadLine()?.Trim().ToLower() != "s") { Console.WriteLine("  Operación cancelada."); return; }

            _db.EliminarProducto(id);
            Exito("Producto eliminado.");
        }

        // ── INVENTARIO ────────────────────────────────────────────────────

        private void MenuInventario()
        {
            bool volver = false;
            while (!volver)
            {
                Console.WriteLine();
                Separador("MOVIMIENTOS DE INVENTARIO");
                Console.WriteLine("  1. Registrar entrada de mercadería");
                Console.WriteLine("  2. Registrar salida de mercadería");
                Console.WriteLine("  3. Ajuste de inventario");
                Console.WriteLine("  4. Ver historial de movimientos");
                Console.WriteLine("  5. Ver movimientos por producto");
                Console.WriteLine("  6. Volver");
                Console.WriteLine();

                switch (Leer("Opción"))
                {
                    case "1": RegistrarMovimiento(TipoMovimiento.Entrada); break;
                    case "2": RegistrarMovimiento(TipoMovimiento.Salida);  break;
                    case "3": RegistrarMovimiento(TipoMovimiento.Ajuste);  break;
                    case "4": VerHistorial();                              break;
                    case "5": VerMovimientosPorProducto();                 break;
                    case "6": volver = true;                               break;
                    default:  Error("Opción no válida.");                  break;
                }
            }
        }

        private void RegistrarMovimiento(TipoMovimiento tipo)
        {
            Console.WriteLine();
            Separador($"REGISTRAR {tipo.ToString().ToUpper()}");

            int id = LeerEntero("ID del producto");
            var producto = _db.BuscarProducto(id);

            if (producto == null) { Error("Producto no encontrado."); return; }

            Console.WriteLine($"\n  Producto : {producto.Nombre}");
            Console.WriteLine($"  Stock actual: {producto.Stock} unidades");

            int cantidad = LeerEntero("Cantidad");
            if (cantidad <= 0) { Error("La cantidad debe ser mayor a 0."); return; }

            if (tipo == TipoMovimiento.Salida && cantidad > producto.Stock)
            {
                Error($"Stock insuficiente. Disponible: {producto.Stock} unidades.");
                return;
            }

            string motivo = Leer("Motivo / Referencia");

            // Actualizar stock
            int stockAntes = producto.Stock;
            producto.Stock = tipo switch
            {
                TipoMovimiento.Entrada => producto.Stock + cantidad,
                TipoMovimiento.Salida  => producto.Stock - cantidad,
                TipoMovimiento.Ajuste  => cantidad,
                _                      => producto.Stock
            };

            _db.ActualizarProducto(producto);

            // Registrar movimiento
            var mov = new Movimiento
            {
                ProductoId     = producto.Id,
                ProductoNombre = producto.Nombre,
                Tipo           = tipo,
                Cantidad       = tipo == TipoMovimiento.Ajuste ? Math.Abs(producto.Stock - stockAntes) : cantidad,
                Motivo         = motivo
            };
            _db.RegistrarMovimiento(mov);

            Exito($"Movimiento registrado. Stock actualizado: {stockAntes} → {producto.Stock} unidades.");
        }

        private void VerHistorial()
        {
            var movimientos = _db.ObtenerMovimientos();
            Console.WriteLine();
            Separador("HISTORIAL DE MOVIMIENTOS");

            if (!movimientos.Any()) { Console.WriteLine("  No hay movimientos registrados."); Pausa(); return; }

            foreach (var m in movimientos.OrderByDescending(m => m.Fecha).Take(50))
                Console.WriteLine($"  {m}");

            Console.WriteLine($"\n  Mostrando últimos {Math.Min(50, movimientos.Count)} de {movimientos.Count} movimientos.");
            Pausa();
        }

        private void VerMovimientosPorProducto()
        {
            Console.WriteLine();
            int id = LeerEntero("ID del producto");
            var producto = _db.BuscarProducto(id);

            if (producto == null) { Error("Producto no encontrado."); return; }

            var movimientos = _db.ObtenerMovimientosPorProducto(id);
            Separador($"MOVIMIENTOS: {producto.Nombre}");

            if (!movimientos.Any()) { Console.WriteLine("  Sin movimientos registrados."); Pausa(); return; }

            foreach (var m in movimientos.OrderByDescending(m => m.Fecha))
                Console.WriteLine($"  {m}");

            Pausa();
        }

        // ── REPORTES ──────────────────────────────────────────────────────

        private void MenuReportes()
        {
            bool volver = false;
            while (!volver)
            {
                Console.WriteLine();
                Separador("REPORTES");
                Console.WriteLine("  1. Resumen general");
                Console.WriteLine("  2. Productos con stock bajo");
                Console.WriteLine("  3. Inventario valorizado por categoría");
                Console.WriteLine("  4. Volver");
                Console.WriteLine();

                switch (Leer("Opción"))
                {
                    case "1": ReporteResumen();    break;
                    case "2": ReporteStockBajo();  break;
                    case "3": ReportePorCategoria(); break;
                    case "4": volver = true;       break;
                    default:  Error("Opción no válida."); break;
                }
            }
        }

        private void ReporteResumen()
        {
            var (totalProd, totalUnidades, valorTotal) = _db.ObtenerResumen();
            var movimientos = _db.ObtenerMovimientos();
            var stockBajo = _db.ObtenerStockBajo();

            Console.WriteLine();
            Separador("RESUMEN GENERAL DE BODEGA");
            Console.WriteLine($"  Total de productos  : {totalProd}");
            Console.WriteLine($"  Total de unidades   : {totalUnidades:N0}");
            Console.WriteLine($"  Valor del inventario: S/ {valorTotal:N2}");
            Console.WriteLine($"  Movimientos totales : {movimientos.Count}");
            Console.WriteLine($"  Productos stock bajo: {stockBajo.Count} {(stockBajo.Any() ? "⚠" : "✓")}");
            Pausa();
        }

        private void ReporteStockBajo()
        {
            int umbral = LeerEntero("Umbral de stock bajo (default 5)");
            if (umbral <= 0) umbral = 5;

            var productos = _db.ObtenerStockBajo(umbral);
            Console.WriteLine();
            Separador($"PRODUCTOS CON STOCK ≤ {umbral}");

            if (!productos.Any()) { Exito($"No hay productos con stock ≤ {umbral}."); return; }

            Console.WriteLine($"  {"ID",-6} {"Nombre",-25} {"Stock",8} {"Proveedor",-20}");
            Console.WriteLine("  " + new string('─', 65));

            foreach (var p in productos.OrderBy(p => p.Stock))
                Console.WriteLine($"  [{p.Id:D4}] {p.Nombre,-25} {p.Stock,8} {p.Proveedor,-20}  ⚠");

            Console.WriteLine($"\n  {productos.Count} producto(s) requieren reabastecimiento.");
            Pausa();
        }

        private void ReportePorCategoria()
        {
            var productos = _db.ObtenerProductos();
            Console.WriteLine();
            Separador("INVENTARIO POR CATEGORÍA");

            var grupos = productos
                .GroupBy(p => p.Categoria)
                .OrderBy(g => g.Key);

            Console.WriteLine($"  {"Categoría",-20} {"Productos",10} {"Unidades",10} {"Valor total",15}");
            Console.WriteLine("  " + new string('─', 60));

            decimal granTotal = 0;
            foreach (var g in grupos)
            {
                decimal valor = g.Sum(p => p.Stock * p.PrecioUnitario);
                granTotal += valor;
                Console.WriteLine($"  {g.Key,-20} {g.Count(),10} {g.Sum(p => p.Stock),10} S/{valor,13:N2}");
            }

            Console.WriteLine("  " + new string('─', 60));
            Console.WriteLine($"  {"TOTAL",-20} {productos.Count,10} {productos.Sum(p => p.Stock),10} S/{granTotal,13:N2}");
            Pausa();
        }

        // ── Helpers UI ────────────────────────────────────────────────────

        private void MostrarBienvenida()
        {
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine(@"
  ╔═══════════════════════════════════════╗
  ║     SISTEMA DE GESTIÓN DE BODEGA      ║
  ║           v1.0 - C# / TXT DB          ║
  ╚═══════════════════════════════════════╝");
            Console.ResetColor();
            Console.WriteLine($"  Fecha: {DateTime.Now:dd/MM/yyyy HH:mm}\n");
        }

        private void Separador(string titulo)
        {
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine($"  ──── {titulo} ────");
            Console.ResetColor();
        }

        private void Exito(string msg)
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine($"\n  ✓ {msg}");
            Console.ResetColor();
            Pausa();
        }

        private void Error(string msg)
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine($"\n  ✗ {msg}");
            Console.ResetColor();
            Pausa();
        }

        private void Pausa()
        {
            Console.ForegroundColor = ConsoleColor.DarkGray;
            Console.Write("\n  Presione Enter para continuar...");
            Console.ResetColor();
            Console.ReadLine();
        }

        private string Leer(string etiqueta)
        {
            Console.Write($"  {etiqueta}: ");
            return Console.ReadLine() ?? string.Empty;
        }

        private int LeerEntero(string etiqueta)
        {
            while (true)
            {
                Console.Write($"  {etiqueta}: ");
                if (int.TryParse(Console.ReadLine(), out int valor)) return valor;
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("  Ingrese un número entero válido.");
                Console.ResetColor();
            }
        }

        private decimal LeerDecimal(string etiqueta)
        {
            while (true)
            {
                Console.Write($"  {etiqueta}: ");
                if (decimal.TryParse(Console.ReadLine(), out decimal valor)) return valor;
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("  Ingrese un valor numérico válido.");
                Console.ResetColor();
            }
        }
    }
}
