using System.IO;

namespace Bodega
{
    public class BodegaDB
    {
        private readonly string _dirData;
        private readonly string _archivoProductos;
        private readonly string _archivoMovimientos;
        private readonly string _archivoContadores;

        public BodegaDB(string directorio = "datos")
        {
            _dirData            = directorio;
            _archivoProductos   = Path.Combine(_dirData, "productos.txt");
            _archivoMovimientos = Path.Combine(_dirData, "movimientos.txt");
            _archivoContadores  = Path.Combine(_dirData, "contadores.txt");

            InicializarArchivos();
        }

        // ── Inicialización ────────────────────────────────────────────────

        private void InicializarArchivos()
        {
            Directory.CreateDirectory(_dirData);

            if (!File.Exists(_archivoProductos))
                File.WriteAllText(_archivoProductos, string.Empty);

            if (!File.Exists(_archivoMovimientos))
                File.WriteAllText(_archivoMovimientos, string.Empty);

            if (!File.Exists(_archivoContadores))
                File.WriteAllLines(_archivoContadores, new[] { "productos=0", "movimientos=0" });
        }

        // ── Contadores (IDs autoincrementales) ────────────────────────────

        private int ObtenerSiguienteId(string entidad)
        {
            var lineas = File.ReadAllLines(_archivoContadores).ToList();
            int nuevo = 0;

            for (int i = 0; i < lineas.Count; i++)
            {
                if (lineas[i].StartsWith(entidad + "="))
                {
                    nuevo = int.Parse(lineas[i].Split('=')[1]) + 1;
                    lineas[i] = $"{entidad}={nuevo}";
                    break;
                }
            }

            File.WriteAllLines(_archivoContadores, lineas);
            return nuevo;
        }

        // ── CRUD Productos ────────────────────────────────────────────────

        public List<Producto> ObtenerProductos()
        {
            return File.ReadAllLines(_archivoProductos)
                       .Where(l => !string.IsNullOrWhiteSpace(l))
                       .Select(Producto.FromCsv)
                       .ToList();
        }

        public Producto? BuscarProducto(int id)
            => ObtenerProductos().FirstOrDefault(p => p.Id == id);

        public List<Producto> BuscarProductosPorNombre(string termino)
            => ObtenerProductos()
               .Where(p => p.Nombre.Contains(termino, StringComparison.OrdinalIgnoreCase))
               .ToList();

        public List<Producto> BuscarProductosPorCategoria(string categoria)
            => ObtenerProductos()
               .Where(p => p.Categoria.Equals(categoria, StringComparison.OrdinalIgnoreCase))
               .ToList();

        public Producto AgregarProducto(Producto producto)
        {
            producto.Id = ObtenerSiguienteId("productos");
            File.AppendAllText(_archivoProductos, producto.ToCsv() + Environment.NewLine);
            return producto;
        }

        public bool ActualizarProducto(Producto actualizado)
        {
            var productos = ObtenerProductos();
            int idx = productos.FindIndex(p => p.Id == actualizado.Id);
            if (idx < 0) return false;

            productos[idx] = actualizado;
            GuardarProductos(productos);
            return true;
        }

        public bool EliminarProducto(int id)
        {
            var productos = ObtenerProductos();
            int antes = productos.Count;
            productos.RemoveAll(p => p.Id == id);

            if (productos.Count == antes) return false;
            GuardarProductos(productos);
            return true;
        }

        private void GuardarProductos(List<Producto> productos)
        {
            File.WriteAllLines(_archivoProductos, productos.Select(p => p.ToCsv()));
        }

        // ── CRUD Movimientos ──────────────────────────────────────────────

        public List<Movimiento> ObtenerMovimientos()
        {
            return File.ReadAllLines(_archivoMovimientos)
                       .Where(l => !string.IsNullOrWhiteSpace(l))
                       .Select(Movimiento.FromCsv)
                       .ToList();
        }

        public List<Movimiento> ObtenerMovimientosPorProducto(int productoId)
            => ObtenerMovimientos().Where(m => m.ProductoId == productoId).ToList();

        public Movimiento RegistrarMovimiento(Movimiento movimiento)
        {
            movimiento.Id   = ObtenerSiguienteId("movimientos");
            movimiento.Fecha = DateTime.Now;
            File.AppendAllText(_archivoMovimientos, movimiento.ToCsv() + Environment.NewLine);
            return movimiento;
        }

        // ── Utilidades ────────────────────────────────────────────────────

        public List<Producto> ObtenerStockBajo(int umbral = 5)
            => ObtenerProductos().Where(p => p.Stock <= umbral).ToList();

        public List<string> ObtenerCategorias()
            => ObtenerProductos().Select(p => p.Categoria).Distinct().OrderBy(c => c).ToList();

        public (int totalProductos, int totalUnidades, decimal valorTotal) ObtenerResumen()
        {
            var productos = ObtenerProductos();
            return (
                productos.Count,
                productos.Sum(p => p.Stock),
                productos.Sum(p => p.Stock * p.PrecioUnitario)
            );
        }
    }
}
